
#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
# More info in the main Magisk thread

# Wait for boot to be completed
while [ `getprop sys.boot_completed` != "1" ]; do
    sleep 1s
done

# Apply settings
sleep 20s

swapoff /dev/block/zram0 > /dev/null 2>&1
echo 1 > /sys/block/zram0/reset
echo lz4 > /sys/block/zram0/comp_algorithm
echo 8 > /sys/block/zram0/max_comp_streams
echo 536870912 > /sys/block/zram0/disksize
mkswap /dev/block/zram0 > /dev/null 2>&1
swapon /dev/block/zram0 > /dev/null 2>&1

echo 10 > /sys/class/thermal/thermal_message/sconfig

echo 830000000 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
echo 830000000 > /sys/devices/platform/soc/2c00000.qcom,kgsl-3d0/devfreq/2c00000.qcom,kgsl-3d0/max_freq
echo 830 > /sys/devices/platform/soc/2c00000.qcom,kgsl-3d0/kgsl/kgsl-3d0/max_clock_mhz
echo 0 > /sys/devices/platform/soc/2c00000.qcom,kgsl-3d0/kgsl/kgsl-3d0/max_pwrlevel


echo N > /sys/module/sync/parameters/fsync_enabled

echo 65 > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_load
echo 65 > /sys/devices/system/cpu/cpu5/cpufreq/schedutil/hispeed_load
echo 65 > /sys/devices/system/cpu/cpu6/cpufreq/schedutil/hispeed_load
echo 65 > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_load
echo 2419200 > /sys/devices/system/cpu/cpu4/cpufreq/schedutil/hispeed_freq
echo 2419200 > /sys/devices/system/cpu/cpu5/cpufreq/schedutil/hispeed_freq
echo 2419200 > /sys/devices/system/cpu/cpu6/cpufreq/schedutil/hispeed_freq
echo 2841600 > /sys/devices/system/cpu/cpu7/cpufreq/schedutil/hispeed_freq
echo 80 > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_load
echo 80 > /sys/devices/system/cpu/cpu1/cpufreq/schedutil/hispeed_load
echo 80 > /sys/devices/system/cpu/cpu2/cpufreq/schedutil/hispeed_load
echo 80 > /sys/devices/system/cpu/cpu3/cpufreq/schedutil/hispeed_load
echo 1785600 > /sys/devices/system/cpu/cpu0/cpufreq/schedutil/hispeed_freq
echo 1785600 > /sys/devices/system/cpu/cpu1/cpufreq/schedutil/hispeed_freq
echo 1785600 > /sys/devices/system/cpu/cpu2/cpufreq/schedutil/hispeed_freq
echo 1785600 > /sys/devices/system/cpu/cpu3/cpufreq/schedutil/hispeed_freq

echo 1 > /sys/devices/system/cpu/cpu4/core_ctl/min_cpus
echo 4 > /sys/devices/system/cpu/cpu4/core_ctl/task_thres
echo 20 > /sys/devices/system/cpu/cpu4/core_ctl/busy_down_thres
echo 40 > /sys/devices/system/cpu/cpu4/core_ctl/busy_up_thres
echo 500 > /sys/devices/system/cpu/cpu4/core_ctl/offline_delay_ms

fi;
